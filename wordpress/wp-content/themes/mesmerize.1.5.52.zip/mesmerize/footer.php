	<?php mesmerize_get_footer_content(); ?>
	</div>
<?php wp_footer(); ?>
</body>
</html>
